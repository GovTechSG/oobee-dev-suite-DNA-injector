# oobee-genome

Automatic source location tracking for DOM elements across multiple build tools.

## Install

To install from your S3-backed npm registry, configure `.npmrc`:

```ini
registry=http://oobee-genome-npm-registry.s3-website-ap-southeast-1.amazonaws.com/
always-auth=false
```

Then install the package normally:

```bash
npm install oobee-genome
```

This S3 static registry flow does not use `npm adduser` or auth tokens.

## Usage

### Vite

```js
import oobeeVite from "oobee-genome/adapters/vite";
```

### Webpack

```js
loader: require.resolve("oobee-genome/adapters/webpack");
```

### Next.js

```js
const { withOobeeDNA } = require("oobee-genome/adapters/next");
```

## Publish

From the package directory:

```bash
cd oobee-genome
npm run publish:s3
```

Use `node s3-publish.js --dry-run` to validate tarball/metadata generation before uploading to S3.
